from sqlalchemy.ext.declarative import declarative_base

# Declare the base for all SQLAlchemy models
Base = declarative_base()
